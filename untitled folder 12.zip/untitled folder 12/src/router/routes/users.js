import { USERS } from '@/constants/layouts';
import {
  RT_WINDOW,
  MT_WINDOW
} from '@/constants/routes/users.js';

export default [
  {
    path: '/',
    name: 'RT_WINDOW',
    component: () => import('@/views/Users/Home.vue'),
    meta: {
      layout: USERS,
      title: 'MT_WINDOW'
    }
  }
];
