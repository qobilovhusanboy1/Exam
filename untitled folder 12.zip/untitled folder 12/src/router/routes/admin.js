import { ADMIN } from '@/constants/layouts';

import {
  RT_ADMIN,
  MT_ADMIN,
  RT_ORDER,
  MT_ORDER
} from '@/constants/routes/admin';

export default [
  {
    path: '/admin/home',
    name: RT_ADMIN,
    component: () => import('@/views/Admin/Admins.vue'),
    meta: {
      layout: ADMIN,
      title: MT_ADMIN
    }
  },
  {
    path: '/admin',
    name: RT_ORDER,
    component: () => import('@/views/Admin/Home.vue'),
    meta: {
      layout: ADMIN,
      title: MT_ORDER
    }
  }
];
