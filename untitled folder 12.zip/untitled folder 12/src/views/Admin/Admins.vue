<template>
  <div class="mt-5">
    <div v-if="loading" class="relative text-center">
      <Loading />
    </div>
    <VTable v-else :items="orders" />
  </div>
</template>

<script setup>
import Loading from '@/components/loading.vue';
import VTable from '@/components/Admin/AdminsTable.vue';
import { useI18n } from 'vue-i18n';

import { useAdmin } from '@/composables/admin';
const { orders, loading } = useAdmin();
const { t } = useI18n();
</script>
