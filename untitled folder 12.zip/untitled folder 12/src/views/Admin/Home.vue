<template>
  <div class="mt-5">
    <div v-if="loading" class="relative text-center">
      <Loading />
    </div>
    <VTable v-else :items="admins" />
  </div>
</template>
<script setup>
import Loading from '@/components/loading.vue';
import VTable from '@/components/Admin/OrdersTable.vue';
import { useI18n } from 'vue-i18n';

import { useAdmin } from '@/composables/admin';
const { admins, loading } = useAdmin();

const { t } = useI18n();
</script>
