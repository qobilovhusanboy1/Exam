<template>
  <div>
    <h1 class="flex justify-center font-bold text-[30px] text-red-800">404 Error Page</h1>
  </div>
</template>
