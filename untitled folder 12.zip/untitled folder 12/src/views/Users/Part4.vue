<template>
    <div class="bg-black rounded-xl justify-center items-center w-full p-20 ">
        <h1 class="text-[30px] font-[600] text-white">Разрабатываем продукт “INCTAGRAM”</h1>
        <p class="mt-5 text-white">Сразу после попадания в «Карьерный бустер» вы будете работать над учебным <br> проектом “INCTAGRAM” и прокачивать практические навыки, а далее мы отправим <br> вас на реальные стартапы.</p>
        <div class="flex w-[50%]">
            <div class="mt-5 w-full">
                <button class="p-7 border-white border-solid border-[1px] w-full rounded-xl text-[30px] buttonhover">О проекте</button>
                <button class="p-7 border-white border-solid border-[1px] w-full rounded-xl mt-5 text-[30px] buttonhover">Возможности платформы</button>
                <button class="p-7 border-white border-solid border-[1px] w-full rounded-xl mt-5 text-[30px] buttonhover">Технологии</button>
            </div>
        </div>
  </div>
</template>
<script>
</script>

<style>
.btn{
    padding: 7px;
    border-radius: white ;
    width: 100%;   
}

.buttonhover:hover{
  background-color: white;
  color: black;
}
</style>