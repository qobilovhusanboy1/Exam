<template>
  <div class="main flex w-full bg-black">
    <div class="mt-5 text-[15px] font-[600] ml-40">
      <h1 class="text-[50px] text-white">Карьерный бустер для</h1>
      <h1 class="text-[50px]">back-end разработчиков</h1>
      <p class="mt-10 text-[#959596]">Получите коммерческий опыт на реальных стартапах, прокачайте tech & soft <br> навыки, научитесь работать в команде, проходить собеседования и получите<br> первую работу в IT!</p>
      <div class="flex mt-10 ">
        <span class=" text-[20px] text-white "> <span class="text-[#959596]">когда?</span> <br> Старт: <br>29 января</span>
        <span class="ml-20 text-[20px] text-white "> <span class="text-[#959596]">сколько стоит?</span> <br>Стоимость: <br>600€</span>
        <span class="ml-20 text-[20px] text-white "> <span class="text-[#959596]">сколько длится?</span> <br> Длительность: <br>≈5 месяцев</span>
      </div>
      <button class="p-4 pl-15 pr-15 text-white bg-[#FF0807] rounded-2xl text-[20px] mt-20">Записаться</button>
    </div>
    <div class="">
      <img src="/src/assets/images/leftBrace.webp" alt="">
      <img src="/src/assets/images/intershipCommandPhoto.webp" alt="">
      <img src="/src/assets/images/rightBrace.webp" alt="">
    </div>
  </div>
  <Part2/>
  <Part3/>
  <Part4/>
  
  
</template>

<script setup>
import Part2 from "../Student/Part2.vue"
import Part3 from "../Student/Part3.vue"
import Part4 from "../Student/Part4.vue"

</script>
<style >
.main{
  margin: 0;
  padding: 0;
  width: auto;
  background-image: url("/src/assets/images/backgroundHeroSection.jpeg");
}
.main2{
  background-image: url("/src/assets/images/backgroundFooterBlock.jpeg");
}
</style>