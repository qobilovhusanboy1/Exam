<template>
    <div class="bg-black rounded-xl justify-center items-center w-full p-20 ">
     <h1 class="text-[40px] font-[600] ">Для успешного трудоустройства вам нужен</h1> 
     <h1 class="text-[30px] font-[600] text-[#FF0807]">карьерный бустер от IT-incubator</h1>
      <div class="mt-10 flex">
        <div class="w-[70%]" >
          <div class="border jusdtify-center items-center w-full bg-white rounded-xl p-10 pl-5">
          <h1  class="text-[20px] font-[500] mt-10">Получайте ценный коммерческий опыт</h1>
          <p>Работа на стажировке – это реальные условия, в которых <br> работает программист. Вы погрузитесь в процесс <br> разработки, который станет прочной опорой для <br> прохождения собеседования.</p>
          </div>

          <div class="border  w-full bg-white rounded-xl pl-5 pt-10 pb-10 mt-2">
            <h1 class="text-[20px] font-[500] mt-10">Работайте в команде</h1>
            <p>Вы будете работать в реальных командах, используя самые <br> актуальные инструменты Jira, Confluence и т.д. Решая <br> задачи ежедневно и работая по методологиям Scrum/Agile, <br> вы освоите рабочий процесс и погрузитесь в коллективный <br> процесс разработки.</p>
          </div>

          <div class="border jusdtify-center items-center w-full bg-white rounded-xl p-10 pl-5 mt-2">
            <h1 class="text-[20px] font-[500] mt-10">Получайте ценный коммерческий опыт</h1>
            <p>Работа на стажировке – это реальные условия, в которых <br> работает программист. Вы погрузитесь в процесс <br> разработки, который станет прочной опорой для <br> прохождения собеседования.</p>
          </div>
        </div>
        <div class="ml-5 w-[700px] ">
          <img class="rounded-xl h-[784px]" src="/src/assets/images/approachToLearningImage1.webp" alt="">
        </div>
     </div>
  </div>
</template>
<style>
</style>