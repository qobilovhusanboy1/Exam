<template>
    <div class="bg-white rounded-3xl justify-center items-center w-full p-20 ">
       <h1 class="text-[40px] font-[600] ">Добро пожаловать в замкнутый круг!</h1> 
       <div class="flex mt-10 justify-center  items-center di3v  rounded-3xl text-[20px] font-[700] ">
        <span class="text-white text-[20px] font-[600]">Не берут на работу, потому <br> что нет опыта</span>
        <img class="w-[300px] h-[150px] ml-10" src="/src/assets/images/lookingForWorkImage.webp"  alt="">
        <span class="text-white text-[20px] font-[600]">А опыта нет, потому что не берут на работу</span>
       </div>
       <h1 class="mt-10 text-[30px] font-[600]">На это есть 3 причины:</h1>
       <div class="flex justify-between mt-10">
         <div class="border rounded-xl w-[370px] h-[200px] p-5">
            <span class="text-[rgb(139,139,139)]">один</span>
            <h1 class="text-[20px] font-[500] mt-10">Нет коммерческого <br> опыта</h1>
         </div>
         <div class="border rounded-xl  w-[370px] h-[200px] p-5">
            <span class="text-[#8B8B8B]">два</span>
            <h1 class="text-[20px] font-[500] mt-10">Нет опыта в прохождении<br>собеседований</h1>
         </div>
         <div class="border rounded-xl w-[370px] h-[200px] p-5">
            <span class="text-[#8B8B8B]">три</span>
            <h1 class="text-[20px] font-[500] mt-10">Нет опыта работы в <br> команде</h1>
         </div>
       </div>
    </div>
</template>
<style>
    .di3v{
        width: 100%;
        background-image: url("../../assets/images/backgroundFooterBlock.jpeg");
    }
</style>