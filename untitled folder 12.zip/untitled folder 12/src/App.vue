<template>
  <app-layout>
    <router-view />
  </app-layout>
</template>

<script setup>
import AppLayout from '@/layouts/AppLayout.vue';
</script>

<style>
::-webkit-scrollbar {
  display: none;
}
</style>
