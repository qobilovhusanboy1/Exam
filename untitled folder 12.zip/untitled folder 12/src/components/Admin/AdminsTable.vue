<template>
    <v-table >
      <thead>
        <tr>
          <th class="text-left"> ID </th>
          <th class="text-left">Phone Number</th>
          <th class="text-left">Email</th>
          <th class="text-left">Message</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item">
          <td>{{ item.order_id }}</td>
          <td>{{ item.phone }}</td>
          <td>{{ item.email }}</td>
          <td>{{ item.name }}</td>
        </tr>
      </tbody>
    </v-table>
  </template>
  
  <script setup>
  import { useI18n } from 'vue-i18n';
  
  const { t } = useI18n();
  const props = defineProps({
    items: {
      type: Array,
      required: true
    }
  });
  </script>
  