<template>
    <v-table >
      <thead>
        <tr>
          <th class="text-left"> ID </th>
          <th class="text-left">Firstname</th>
          <th class="text-left">UserName</th>
          <th class="text-left">Hashed Password</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.admin_id">
          <td>{{ item.admin_id }}</td>
          <td>{{ item.first_name }}</td>
          <td>{{ item.user_name }}</td>
          <td>{{ item.hashed_password }}</td>
        </tr>
      </tbody>
    </v-table>
  </template>
  
  <script setup>
  import { useI18n } from 'vue-i18n';
  
  const { t } = useI18n();
  const props = defineProps({
    items: {
      type: Array,
      required: true
    }
  });
  </script>
  