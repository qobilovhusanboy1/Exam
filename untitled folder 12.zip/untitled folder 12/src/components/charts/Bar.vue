<template>
  <Bar
    id="my-chart-id"
    :options="chartDatas.chartOptions"
    :data="chartDatas.chartData"
    style="color: red"
  />
</template>

<script setup>
import { Bar } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale
} from 'chart.js';

import { reactive } from 'vue';

ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale);

const chartDatas = reactive({
  chartData: {
    labels: ['January', 'February'],
    datasets: [
      {
        label: 'Dataset 1',
        data: [1, 2, 3],
        borderColor: '#36A2EB',
        backgroundColor: '#9BD0F5'
      },
      {
        label: 'Dataset 2',
        data: [2, 3, 4],
        borderColor: '#FF6384',
        backgroundColor: '#FFB1C1'
      }
    ]
  },
  chartOptions: {
    responsive: true
  }
});
</script>
