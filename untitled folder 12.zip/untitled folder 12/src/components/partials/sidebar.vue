<script setup>
import VButton from '../button.vue';
import { useI18n } from 'vue-i18n';
import { useAuthStore } from '@/store/auth';

const store = useAuthStore();

const handleLogout = () => {
  store.clearUser();
};
const { t } = useI18n();

defineProps({
  permanent: {
    type: Boolean,
    default: false
  },
  routes: {
    type: Array,
    required: true
  }
});
</script>

<template>
  <v-navigation-drawer color="blue" :permanent="permanent" class="text-left ">
    <div class="justify-center items-center flex mt-10 p-5 font-[700]">ADMIN PANEL</div>
    <div class="mt-10 justify-center items-center">
      <router-link
        v-for="(link, index) in routes"
        :key="index"
        :to="{ name: link.name }"
        class="block w-5/6 transition-all text-black text-center text-[18px] rounded-md mx-auto mb-3 p-2"
      >
        <span class="fa-solid me-3" :class="link.icon" />
        <span>{{ t(`${link.text}`) }}</span>
      </router-link>
    </div> 
    <v-button
      @click="handleLogout"
      class="w-3/6 flex justify-center mx-auto p-2 my-10"
      prepend-icon
      icon="mdi-logout"
      color="white"
      >{{ t('login.loguot') }}</v-button
    >
  </v-navigation-drawer>
</template>

<style scoped>
.router-link-exact-active {
  background-color: white;
}
</style>
