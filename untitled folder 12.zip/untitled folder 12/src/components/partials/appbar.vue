<template>
  <v-app-bar :elevation="1" color="#fdfdfd" class="py-2 flex items-center justify-between">
    <div class="flex justify-center w-[30%]">
      <h2 class="uppercase text-[20px] font-[700] text-black">IT •<span class="border-solid rounded-3xl border-black p-1 border-[2px] mr-1 ml-1"> IN </span>CUBATOR</h2>
    </div>
    <div class="text-[15px] font-[700] text-black flex justify-center items-center">
      <h2 class="ml-20 p-3">Learn with us</h2>
      <h2 class="ml-5 p-3">Company</h2>
      <h2 class="ml-5 p-3">News</h2>
      <h2 class="ml-5 p-3">Help2Debug</h2>
      <router-link to="/login"><button class="ml-10 bg-black text-white p-3 rounded-lg pl-10 pr-10 ">LOGIN</button></router-link>
      
      <langSwitcher class="ml-10 p-3" />
    </div>
  </v-app-bar>
</template>

<script setup>
import { ref } from 'vue';

import langSwitcher from '@/components/langSwitcher.vue';




const permanent = ref(false);
const emit = defineEmits(['toggleSidebar']);

function CheckToken(){
  
}

function onSidebarToggle() {
  permanent.value = !permanent.value;
  emit('toggleSidebar', permanent.value);
}

</script>

<style >
  .AuthButton:hover{
    background-color: red;
  }
</style>
