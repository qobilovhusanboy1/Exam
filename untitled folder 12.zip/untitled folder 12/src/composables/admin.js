import { useAdminStore } from '@/store/admin';
import { storeToRefs } from 'pinia';
import { onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';

export const useAdmin = () => {
  const store = useAdminStore();
  const router = useRouter();
  const route = useRoute();

  const { loading, admins, orders } = storeToRefs(store);
  const {
    login,
    getAdmins,
    getOrdersList
  } = useAdminStore();

  onMounted(async () => {
    await getAdmins();
  });

  onMounted(async () =>{
    await getOrdersList()
  })

  return {
    login,
    loading,
    admins,
    orders,
    route,
    router
  };
};
