<template>
  <v-main>
    <slot />
  </v-main>
</template>

<script setup></script>
