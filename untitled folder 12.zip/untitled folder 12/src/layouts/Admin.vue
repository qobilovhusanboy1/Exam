<template>
  <sidebar :routes="adminRoutes"/>
  <div class="mt-10 bg-white">
    <v-main class="overflow-y-scroll m-0 p-0">
        <slot />
    </v-main>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import {
  RT_ADMIN,
  MT_ADMIN,
  RT_ORDER,
  MT_ORDER
} from '@/constants/routes/admin';

import Sidebar from '@/components/partials/sidebar.vue';


const adminRoutes = ref([
  {
    text: RT_ADMIN,
    name: MT_ORDER,
    icon: 'fa-person-chalkboard'
  },
  {
    text:RT_ORDER,
    name: MT_ADMIN,
    icon: 'fa-list'
  }
]);

</script>
