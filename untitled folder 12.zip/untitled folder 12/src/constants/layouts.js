const ADMIN = 'Admin';
const AUTH = 'Auth';
const USERS = 'Users';

export {  ADMIN , AUTH,DIRECTOR , USERS };
