const RT_LOGIN = 'Login';
const MT_LOGIN = 'Sign in to Educate platform';

const RT_FORGOT = 'ForgotPassword';
const MT_FORGOT = 'Recover your password';

export { RT_FORGOT, RT_LOGIN, MT_FORGOT, MT_LOGIN };
