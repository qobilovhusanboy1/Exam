
const RT_WINDOW = 'Window';
const MT_WINDOW = 'Window';

export {
    RT_WINDOW,
    MT_WINDOW
};