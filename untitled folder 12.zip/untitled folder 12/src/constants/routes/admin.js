
const RT_ADMIN = 'Admin';
const MT_ADMIN = 'Admin';
const RT_ORDER = 'Order';
const MT_ORDER = 'Order';

export {
  RT_ADMIN,
  MT_ADMIN,
  RT_ORDER,
  MT_ORDER
};
