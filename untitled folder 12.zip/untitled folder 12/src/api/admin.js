import api from '@/plugins/axios';

const url = import.meta.env.VITE_BASE_URL;

function apifetchAdmins() {
  return api.get(url+'/admin/find-all');
}

function apifetchOrders() {
  return api.get(url+`/order/find-all`);
}

function apiAddOrder(order){
  return api.post(url+'/order/add')
}


export {
  apifetchAdmins,
  apifetchOrders,
  apiAddOrder
};
