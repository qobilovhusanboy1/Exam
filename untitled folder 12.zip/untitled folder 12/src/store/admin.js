import { defineStore } from 'pinia';
import {
  apiAddOrder,
  apifetchAdmins,
  apifetchOrders
} from '@/api/admin'
import { errorToast, successToast } from '@/utils/toast';

export const useAdminStore = defineStore('admin', {
  state: () => ({
    admins: [],
    orders: [],
    loading: false,
  }),
  actions: {
    async getAdmins() {
      this.loading = true;
      try {
        const res = await apifetchAdmins();
        if (!res.data?.admins && res.status !== 200) {
          return;
        }

        this.loading = false;
        this.admins = res?.data?.admins;
        console.log(this.admins);
      } catch (error) {
        this.loading = false;
        errorToast(error.message);
      }
    },

    async getOrdersList() {
      this.loading = true;
      try {
        const res = await apifetchOrders();
        if (!res?.data?.order && res.status !== 200) {
          return;
        }
        this.loading = false;
        this.orders = res?.data?.orders;
        console.log(this.orders);
      } catch (error) {
        this.loading = false;
        errorToast(error.message);
      }
    },

    //Teachers
    async AddOrderfunction(newOrder) {
      this.loading = true;
      try {
        const res = await apiAddOrder(newOrder);
        console.log(res);
        if (res.status !== 200) {
          return;
        }
        const res2 = await apifetchOrders();
        if (!res?.data?.order && res.status !== 200) {
          return;
        }
        this.loading = false;
        this.orders = res2?.data?.order;
        console.log(this.orders);
      } catch (error) {
        this.loading = false;
        errorToast(error.message);
      } finally {
        this.loading = false;
      }
    },

  }
});
